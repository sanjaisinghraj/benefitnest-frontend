import RolloutClient from "./RolloutClient";

export const dynamic = "force-dynamic";

export default function Page() {
  return <RolloutClient />;
}
