"use client";

import CorporateManagement from "./CorporateManagement";

export default function CorporatesPage() {
  return <CorporateManagement />;
}
