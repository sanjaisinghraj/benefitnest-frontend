"use client";

import MastersManagement from "./MastersManagement";

export default function MastersPage() {
  return <MastersManagement />;
}
