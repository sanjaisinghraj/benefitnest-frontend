import CostDashboardClient from "./CostDashboardClient";

export const dynamic = "force-dynamic";

export default function Page() {
  return <CostDashboardClient />;
}
