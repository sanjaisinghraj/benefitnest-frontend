import PlanConfigClient from "./PlanConfigClient";

export const dynamic = "force-dynamic";

export default function Page() {
  return <PlanConfigClient />;
}
