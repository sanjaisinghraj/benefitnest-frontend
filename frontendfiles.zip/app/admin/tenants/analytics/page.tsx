import TenantAnalyticsClient from "./TenantAnalyticsClient";

export const dynamic = "force-dynamic";

export default function Page() {
  return <TenantAnalyticsClient />;
}
