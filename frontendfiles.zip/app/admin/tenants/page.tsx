import TenantClient from "./TenantClient";

export const dynamic = "force-dynamic";

export default function Page() {
  return <TenantClient />;
}
