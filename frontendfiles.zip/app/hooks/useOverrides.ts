// Placeholder for useOverrides hook
export function useOverrides() {
  return {};
}
