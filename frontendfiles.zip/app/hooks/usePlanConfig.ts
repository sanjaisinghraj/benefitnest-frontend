// Placeholder for usePlanConfig hook
export function usePlanConfig() {
  return {};
}
