// Placeholder for useEnrollment hook
export function useEnrollment() {
  return {};
}
