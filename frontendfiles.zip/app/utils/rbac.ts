// Placeholder for RBAC utility
// Use the real RBAC utility from ../../utils/rbac.ts
export { hasRole } from "../../utils/rbac";
