import EmployeeEnrollClient from "./EmployeeEnrollClient";

export const dynamic = "force-dynamic";

export default function Page() {
  return <EmployeeEnrollClient />;
}
