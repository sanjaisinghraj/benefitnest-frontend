// Placeholder for PaymentMethodSelector component
export function PaymentMethodSelector(props?: Record<string, unknown>) {
  return null;
}
