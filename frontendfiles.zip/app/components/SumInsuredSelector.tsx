// Placeholder for SumInsuredSelector component
export function SumInsuredSelector(props: any) {
  return null;
}
