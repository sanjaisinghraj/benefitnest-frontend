// Placeholder for RiderOptions component
export function RiderOptions(props?: Record<string, unknown>) {
  return null;
}
