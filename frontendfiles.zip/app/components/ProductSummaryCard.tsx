// Placeholder for ProductSummaryCard component
export function ProductSummaryCard(props?: Record<string, unknown>) {
  return null;
}
